import React from 'react'

function Footer() {
  return (
    <article>
    <h1>sdaasd</h1>
   
    <footer>
        <p>© 2022</p>
    </footer>
</article>
  )
}

export default Footer